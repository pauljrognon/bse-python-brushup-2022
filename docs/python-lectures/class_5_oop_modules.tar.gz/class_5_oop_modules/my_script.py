from pycars.main import *
from pycars.utilities import *


if __name__ == '__main__':  # this part of the code runs when we execute the script through the command line
    convertible = Convertible(model='nissan 370z', color='pink', horse_power=300, engine_volume=3.2, year=2012, roof_state='up')
    convertible.drive('left', 1)
    print(convertible.roof_state, convertible.location)
    #MeasureConverter.convertable_to("hp")
    #car = Car('pink', 88)
    #car.drive('left', 1)
    #print(car.location)