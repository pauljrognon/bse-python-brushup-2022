from typing import Union


class Car:
    
    def __init__(self, model: str, color: str, horse_power: int, engine_volume: float, 
                 year: int, location: Union[int, float] = 0) -> None:  # class constructor
        self.model = model
        self.color = color
        self.horse_power = horse_power
        self.location = location
        self.engine_volume = engine_volume
        self.year = year
        
    def drive(self, direction: str, distance: Union[int, float]) -> None:  # class method
        if direction not in ['left', 'right']:
            raise ValueError('Direction has to be either "left" or "right".')
        self.location = self.location + 2 * ((direction == 'right') - 1 / 2) * distance
        print(f"We drive the car towards {direction} direction by {distance}")


class Convertible(Car):  # let's add a class that inherits properties and methods from the Car class
    
    def __init__(self, model: str, color: str, horse_power: int, engine_volume: float, 
                 year: int, roof_state: str, location: Union[int, float] = 0) -> None:
        super().__init__(model, color, horse_power, engine_volume, year, location)  # super() refers to a parent class
        if roof_state not in ['up', 'down']:
            raise ValueError('The roof parameter can be either up or down.')
        self.roof_state = roof_state