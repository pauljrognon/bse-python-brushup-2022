# Extra exercise: Linear models

In this exercise you will need to combine several skills learned during the tutorial as you take a tour around linear models, which are arguably one of the cornerstones of statistical learning theory.

Instructions: complete the file `linearmodels_inclass.Rmd`. The solutions and the html/pdf outputs are provided as well for your convenience.
